#include <QTest>
#include <QSignalSpy>
#include <QDebug>
#include <QCoreApplication>
#include <QTimer>
#include "client.h"

class ClientTests : public QObject
{
    Q_OBJECT

private slots:
    void initTestCase();
    void init();
    void cleanup();
    void cleanupTestCase();
    void testConnection();
    void testMessageSending();
    void testRoomOperations();
    void testListRooms(); // Новый тест

private:
    Client* client;
    QTimer* testTimer;

    int createAndGetRoomId(const QString& roomName = "TestRoom", const QString& password = "password");
    bool joinRoom(int roomId, const QString& password = "password");
};

void ClientTests::initTestCase() {
    qDebug() << "Starting test suite";
    qDebug().noquote().nospace() << Qt::flush;
}

void ClientTests::init() {
    qDebug() << "=== Test initialization started ===";
    qDebug().noquote().nospace() << Qt::flush;

    try {
        client = &Client::getInstance();
        qDebug() << "Client instance obtained";
        qDebug() << "Initial client connected status:" << client->isConnected();

        testTimer = new QTimer(this);
        if (!testTimer) {
            qFatal("Failed to create test timer");
        }
        testTimer->setSingleShot(true);
        connect(testTimer, &QTimer::timeout, this, [this]() {
            qDebug() << "TEST TIMEOUT - Force quitting";
            qDebug() << "Client connected status:" << client->isConnected();
            qDebug().noquote().nospace() << Qt::flush;
            QCoreApplication::exit(1);
        });

        qDebug() << "Test timer initialized";
        qDebug() << "=== Test initialization completed ===";
        qDebug().noquote().nospace() << Qt::flush;
    } catch (const std::exception& e) {
        qFatal("Exception in init: %s", e.what());
    }
}

void ClientTests::cleanup() {
    qDebug() << "=== Test cleanup started ===";
    qDebug().noquote().nospace() << Qt::flush;

    try {
        if (testTimer) {
            testTimer->stop();
            delete testTimer;
            testTimer = nullptr;
            qDebug() << "Test timer cleaned up";
        }

        if (client && client->isConnected()) {
            qDebug() << "Client still connected in cleanup, disconnecting...";
            if (client->getRoomId() != -1) {
                qDebug() << "Leaving room" << client->getRoomId();
                client->leaveRoom();
                QTest::qWait(1000);
            }
            qDebug() << "Disconnecting client";
            client->disconnect();
            QTest::qWait(1000);

            if (client->isConnected()) {
                qDebug() << "WARNING: Client still connected after disconnect attempt";
            } else {
                qDebug() << "Client disconnected successfully";
            }
        } else {
            qDebug() << "Client already disconnected in cleanup";
        }

        qDebug() << "=== Test cleanup completed ===";
        qDebug().noquote().nospace() << Qt::flush;
    } catch (const std::exception& e) {
        qDebug() << "Exception in cleanup:" << e.what();
        qDebug().noquote().nospace() << Qt::flush;
    } catch (...) {
        qDebug() << "Unknown exception in cleanup";
        qDebug().noquote().nospace() << Qt::flush;
    }
}

void ClientTests::cleanupTestCase() {
    qDebug() << "=== Test suite cleanup started ===";
    qDebug().noquote().nospace() << Qt::flush;

    try {
        if (client && client->isConnected()) {
            qDebug() << "Forcing client disconnect in suite cleanup";
            client->disconnect();
            QTest::qWait(1000);
        }
    } catch (...) {
        qDebug() << "Error during final cleanup";
    }

    qDebug() << "=== Test suite cleanup completed ===";
    qDebug().noquote().nospace() << Qt::flush;
}

void ClientTests::testConnection() {
    qDebug() << "\n=== Starting testConnection ===";
    qDebug().noquote().nospace() << Qt::flush;

    try {
        testTimer->start(5000); // 5 секунд на тест
        qDebug() << "Test timer started";

        qDebug() << "Attempting to connect to server...";
        bool connected = client->connectToServer("127.0.0.1", 12346);
        qDebug() << "Connect result:" << connected;
        QVERIFY2(connected, "Failed to connect to server");

        qDebug() << "Checking connection status...";
        QVERIFY2(client->isConnected(), "Client is not connected after successful connection");

        qDebug() << "Connection test completed successfully";
        testTimer->stop();

        if (client->isConnected()) {
            qDebug() << "Disconnecting from server...";
            client->disconnect();
            QTest::qWait(1000); // Даем время на отключение
            QVERIFY2(!client->isConnected(), "Client failed to disconnect");
            qDebug() << "Disconnected successfully";
        }

        qDebug() << "=== testConnection completed ===\n";
        qDebug().noquote().nospace() << Qt::flush;
    } catch (const std::exception& e) {
        qDebug() << "Exception in testConnection:" << e.what();
        qDebug().noquote().nospace() << Qt::flush;
        QFAIL("Exception in testConnection");
    } catch (...) {
        qDebug() << "Unknown exception in testConnection";
        qDebug().noquote().nospace() << Qt::flush;
        QFAIL("Unknown exception in testConnection");
    }
}

void ClientTests::testMessageSending() {
    qDebug() << "\n=== Starting testMessageSending ===";
    qDebug().noquote().nospace() << Qt::flush;

    try {
        init();
        testTimer->start(30000); // 30 секунд на тест

        qDebug() << "Connecting to server...";
        bool connected = client->connectToServer("127.0.0.1", 12346);
        qDebug() << "Connect result:" << connected;
        QVERIFY2(connected, "Failed to connect to server");

        QTest::qWait(1000);
        qDebug() << "Connected successfully";
        qDebug() << "Client connected status:" << client->isConnected();

        int roomId = createAndGetRoomId("MessageTestRoom");
        qDebug() << "Room creation result:" << roomId;
        QVERIFY2(roomId != -1, "Failed to create room");

        bool joined = joinRoom(roomId);
        qDebug() << "Room join result:" << joined;
        QVERIFY2(joined, "Failed to join room");

        qDebug() << "Setting up message monitoring...";
        QSignalSpy messageSpy(client, SIGNAL(messageReceived(int,int,QString)));
        QSignalSpy errorSpy(client, SIGNAL(errorReceived(QString)));

        QString testMessage = "Hello, World!";
        qDebug() << "Sending message:" << testMessage;

        client->sendRequest("MESSAGE:" + QString::number(roomId).toStdString() + ":" + testMessage.toStdString());
        qDebug() << "Message request sent";

        bool messageReceived = false;
        int attempts = 0;
        const int maxAttempts = 50;

        while (!messageReceived && attempts < maxAttempts) {
            if (errorSpy.count() > 0) {
                QString error = errorSpy.takeFirst().at(0).toString();
                qDebug() << "Error received:" << error;
                QFAIL(qPrintable("Error while sending message: " + error));
            }

            while (messageSpy.count() > 0) {
                QList<QVariant> messageArgs = messageSpy.takeFirst();
                qDebug() << "Received message:";
                qDebug() << "- Room ID:" << messageArgs.at(0).toInt();
                qDebug() << "- Sender ID:" << messageArgs.at(1).toInt();
                qDebug() << "- Content:" << messageArgs.at(2).toString();

                if (messageArgs.at(0).toInt() == roomId &&
                    messageArgs.at(2).toString() == testMessage) {
                    messageReceived = true;
                    qDebug() << "Message echo received successfully";
                    break;
                }
            }

            if (!messageReceived) {
                QTest::qWait(100);
                attempts++;

                if (attempts % 10 == 0) {
                    qDebug() << "Waiting for message confirmation... attempt" << attempts;
                    qDebug() << "Client connected status:" << client->isConnected();
                }
            }
        }

        QVERIFY2(messageReceived, "Message confirmation timeout");

        testTimer->stop();
        cleanup();
        qDebug() << "=== testMessageSending completed ===\n";
        qDebug().noquote().nospace() << Qt::flush;
    } catch (const std::exception& e) {
        qFatal("Exception in testMessageSending: %s", e.what());
    }
}

void ClientTests::testRoomOperations() {
    qDebug() << "\n=== Starting testRoomOperations ===";
    qDebug().noquote().nospace() << Qt::flush;

    try {
        init();
        testTimer->start(15000); // 15 секунд на тест

        qDebug() << "Connecting to server...";
        bool connected = client->connectToServer("127.0.0.1", 12346);
        qDebug() << "Connect result:" << connected;
        QVERIFY2(connected, "Failed to connect to server");

        QTest::qWait(1000);
        qDebug() << "Connected successfully";

        int roomId = createAndGetRoomId("OperationsTestRoom");
        qDebug() << "Room creation result:" << roomId;
        QVERIFY2(roomId != -1, "Failed to create room");

        bool joined = joinRoom(roomId);
        qDebug() << "Room join result:" << joined;
        QVERIFY2(joined, "Failed to join room");

        QCOMPARE(client->getRoomId(), roomId);

        testTimer->stop();
        cleanup();
        qDebug() << "=== testRoomOperations completed ===\n";
        qDebug().noquote().nospace() << Qt::flush;
    } catch (const std::exception& e) {
        qFatal("Exception in testRoomOperations: %s", e.what());
    }
}

void ClientTests::testListRooms() {
    qDebug() << "\n=== Starting testListRooms ===";
    qDebug().noquote().nospace() << Qt::flush;

    try {
        init();
        testTimer->start(30000); // 30 секунд на тест

        qDebug() << "Connecting to server...";
        bool connected = client->connectToServer("127.0.0.1", 12346);
        qDebug() << "Connect result:" << connected;
        QVERIFY2(connected, "Failed to connect to server");

        QTest::qWait(1000);
        qDebug() << "Connected successfully";
        qDebug() << "Client connected status:" << client->isConnected();

        // Создаем две тестовые комнаты
        int roomId1 = createAndGetRoomId("TestRoom1", "password1");
        qDebug() << "Room 1 creation result:" << roomId1;
        QVERIFY2(roomId1 != -1, "Failed to create TestRoom1");

        int roomId2 = createAndGetRoomId("TestRoom2", "");
        qDebug() << "Room 2 creation result:" << roomId2;
        QVERIFY2(roomId2 != -1, "Failed to create TestRoom2");

        // Настраиваем мониторинг списка комнат
        QSignalSpy roomListSpy(client, SIGNAL(roomListReceived(QStringList)));
        QSignalSpy errorSpy(client, SIGNAL(errorReceived(QString)));

        qDebug() << "Sending LIST_ROOMS request...";
        client->sendRequest("LIST_ROOMS");
        qDebug() << "LIST_ROOMS request sent";

        // Ожидаем ответа
        bool listReceived = false;
        int attempts = 0;
        const int maxAttempts = 50;

        while (!listReceived && attempts < maxAttempts) {
            if (errorSpy.count() > 0) {
                QString error = errorSpy.takeFirst().at(0).toString();
                qDebug() << "Error received:" << error;
                QFAIL(qPrintable("Error while requesting room list: " + error));
            }

            while (roomListSpy.count() > 0) {
                listReceived = true;
                QList<QVariant> args = roomListSpy.takeFirst();
                QStringList rooms = args.at(0).toStringList();
                qDebug() << "Received room list with" << rooms.size() << "rooms";

                // Проверяем, что список содержит как минимум наши две комнаты
                QVERIFY2(rooms.size() >= 2, "Room list does not contain expected number of rooms");

                // Формат: id:name:hasPassword:participants
                bool foundRoom1 = false, foundRoom2 = false;
                for (const QString& room : rooms) {
                    QStringList parts = room.split(':');
                    qDebug() << "Room entry:" << parts;
                    QVERIFY2(parts.size() == 4, qPrintable("Invalid room format: " + room));

                    int id = parts[0].toInt();
                    QString name = parts[1];
                    QString hasPassword = parts[2];
                    int participants = parts[3].toInt();

                    if (id == roomId1) {
                        QCOMPARE(name, QString("TestRoom1"));
                        QCOMPARE(hasPassword, QString("Yes"));
                        QCOMPARE(participants, 0);
                        foundRoom1 = true;
                        qDebug() << "Found TestRoom1 in list";
                    } else if (id == roomId2) {
                        QCOMPARE(name, QString("TestRoom2"));
                        QCOMPARE(hasPassword, QString("No"));
                        QCOMPARE(participants, 0);
                        foundRoom2 = true;
                        qDebug() << "Found TestRoom2 in list";
                    }
                }

                QVERIFY2(foundRoom1 && foundRoom2, "Not all created rooms found in the list");
                qDebug() << "Room list verification completed";
            }

            if (!listReceived) {
                QTest::qWait(100);
                attempts++;

                if (attempts % 10 == 0) {
                    qDebug() << "Waiting for room list... attempt" << attempts;
                    qDebug() << "Client connected status:" << client->isConnected();
                }
            }
        }

        QVERIFY2(listReceived, "Room list request timeout");

        testTimer->stop();
        cleanup();
        qDebug() << "=== testListRooms completed ===\n";
        qDebug().noquote().nospace() << Qt::flush;
    } catch (const std::exception& e) {
        qFatal("Exception in testListRooms: %s", e.what());
    }
}

int ClientTests::createAndGetRoomId(const QString& roomName, const QString& password) {
    qDebug() << "\n=== Creating room ===";
    qDebug() << "Room name:" << roomName;

    QSignalSpy createSpy(client, SIGNAL(roomCreated(int)));
    QSignalSpy errorSpy(client, SIGNAL(errorReceived(QString)));

    client->sendRequest("CREATE_ROOM:" + roomName.toStdString() + ":" + password.toStdString());
    qDebug() << "Create room request sent";
    qDebug().noquote().nospace() << Qt::flush;

    int attempts = 0;
    while (!createSpy.wait(100) && attempts < 50) {
        QCoreApplication::processEvents();
        if (errorSpy.count() > 0) {
            qDebug() << "Error received:" << errorSpy.takeFirst().at(0).toString();
            qDebug().noquote().nospace() << Qt::flush;
            return -1;
        }
        if (createSpy.count() > 0) break;
        attempts++;
        qDebug() << "Waiting for room creation... attempt" << attempts;
        qDebug().noquote().nospace() << Qt::flush;
    }

    if (createSpy.isEmpty()) {
        qDebug() << "Failed to create room - no response";
        qDebug().noquote().nospace() << Qt::flush;
        return -1;
    }

    QList<QVariant> args = createSpy.takeFirst();
    int roomId = args.at(0).toInt();
    qDebug() << "Room created successfully with ID:" << roomId;
    qDebug() << "=== Room creation completed ===\n";
    qDebug().noquote().nospace() << Qt::flush;
    return roomId;
}

bool ClientTests::joinRoom(int roomId, const QString& password) {
    qDebug() << "\n=== Joining room ===";
    qDebug() << "Target room ID:" << roomId;

    QSignalSpy joinSpy(client, SIGNAL(joinedRoom()));
    QSignalSpy errorSpy(client, SIGNAL(errorReceived(QString)));

    client->sendRequest("JOIN_ROOM:" + QString::number(roomId).toStdString() + ":" + password.toStdString());
    qDebug() << "Join room request sent";
    qDebug().noquote().nospace() << Qt::flush;

    int attempts = 0;
    while (!joinSpy.wait(100) && attempts < 50) {
        QCoreApplication::processEvents();
        if (errorSpy.count() > 0) {
            qDebug() << "Error received:" << errorSpy.takeFirst().at(0).toString();
            qDebug().noquote().nospace() << Qt::flush;
            return false;
        }
        if (joinSpy.count() > 0) break;
        attempts++;
        qDebug() << "Waiting for room join... attempt" << attempts;
        qDebug().noquote().nospace() << Qt::flush;
    }

    if (joinSpy.isEmpty()) {
        qDebug() << "Failed to join room - no response";
        qDebug().noquote().nospace() << Qt::flush;
        return false;
    }

    qDebug() << "Successfully joined room:" << roomId;
    qDebug() << "=== Room join completed ===\n";
    qDebug().noquote().nospace() << Qt::flush;
    return true;
}

int main(int argc, char *argv[])
{
    try {
        QCoreApplication app(argc, argv);

        // Устанавливаем обработчик для вывода отладочной информации
        qInstallMessageHandler([](QtMsgType type, const QMessageLogContext &context, const QString &msg) {
            Q_UNUSED(context);
            QByteArray localMsg = msg.toLocal8Bit();

            switch (type) {
            case QtDebugMsg:
                fprintf(stderr, "Debug: %s\n", localMsg.constData());
                break;
            case QtInfoMsg:
                fprintf(stderr, "Info: %s\n", localMsg.constData());
                break;
            case QtWarningMsg:
                fprintf(stderr, "Warning: %s\n", localMsg.constData());
                break;
            case QtCriticalMsg:
                fprintf(stderr, "Critical: %s\n", localMsg.constData());
                break;
            case QtFatalMsg:
                fprintf(stderr, "Fatal: %s\n", localMsg.constData());
                abort();
            }
            fflush(stderr);
        });

        ClientTests tc;
        QTEST_SET_MAIN_SOURCE_PATH
            return QTest::qExec(&tc, argc, argv);
    } catch (const std::exception& e) {
        fprintf(stderr, "Fatal exception in main: %s\n", e.what());
        return 1;
    } catch (...) {
        fprintf(stderr, "Unknown fatal exception in main\n");
        return 1;
    }
}

#include "client_tests.moc"
